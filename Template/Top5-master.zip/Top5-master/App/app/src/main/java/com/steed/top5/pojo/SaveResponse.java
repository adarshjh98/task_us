package com.steed.top5.pojo;

public class SaveResponse {

    public String statusMessage;
    public boolean isError, isSaved;

    public SaveResponse() {
    }
}
