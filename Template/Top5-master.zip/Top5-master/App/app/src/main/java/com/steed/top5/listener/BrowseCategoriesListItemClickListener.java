package com.steed.top5.listener;

public interface BrowseCategoriesListItemClickListener {

    void OnItemClicked(int index);

}
