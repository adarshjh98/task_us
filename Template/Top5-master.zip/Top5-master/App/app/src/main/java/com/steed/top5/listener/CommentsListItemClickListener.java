package com.steed.top5.listener;

public interface CommentsListItemClickListener {

    void OnDeleteClicked(int index);

}
