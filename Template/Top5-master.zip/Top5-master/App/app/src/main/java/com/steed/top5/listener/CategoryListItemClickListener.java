package com.steed.top5.listener;

import com.steed.top5.pojo.Category;

public interface CategoryListItemClickListener {

	void onItemClicked(Category category);

}
