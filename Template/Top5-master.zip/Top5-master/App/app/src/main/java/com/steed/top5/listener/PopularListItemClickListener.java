package com.steed.top5.listener;

public interface PopularListItemClickListener {

    void OnItemClicked(int index);

}
