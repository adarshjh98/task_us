package com.steed.top5.listener;

public interface UserPreferencesListItemClickListener {

  void OnItemClicked(int index);

}
