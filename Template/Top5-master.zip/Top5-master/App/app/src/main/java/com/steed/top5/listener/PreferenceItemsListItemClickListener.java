package com.steed.top5.listener;

public interface PreferenceItemsListItemClickListener {

	void OnItemClicked(int index);
	void OnPostLikeContainerClicked(int index);
	void OnPostCommentsContainerClicked(int index);
	void OnPostSaveBtnClicked(int index);

}
