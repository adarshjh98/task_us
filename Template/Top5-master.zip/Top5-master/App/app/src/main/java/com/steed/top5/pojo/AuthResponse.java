package com.steed.top5.pojo;

public class AuthResponse {

    public String statusMessage = "";
    public boolean isError = false;
    public User user;

    public AuthResponse() {

    }
}
