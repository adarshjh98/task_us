package com.steed.top5.listener;

public interface BrowseProfilePhotoListener {
    void onSelect(String photoPath);
}
