package com.steed.top5.pojo;

import java.util.ArrayList;

public class FiltersResponse {

    public int filterID;
    public ArrayList<Category> allCategories;
    public ArrayList<String> selectedCategories;

    public FiltersResponse() {
    }
}
