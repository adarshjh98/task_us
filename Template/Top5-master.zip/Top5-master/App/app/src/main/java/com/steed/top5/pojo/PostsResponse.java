package com.steed.top5.pojo;

import java.util.ArrayList;

public class PostsResponse {

    public String statusMessage;
    public boolean isError;
    public ArrayList<Post> posts;

    public PostsResponse() {
    }
}
