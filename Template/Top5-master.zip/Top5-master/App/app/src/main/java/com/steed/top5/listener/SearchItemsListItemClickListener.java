package com.steed.top5.listener;

public interface SearchItemsListItemClickListener {

  void OnItemClicked(int index);

}
