package com.steed.top5.pojo;

import java.util.ArrayList;

public class CommentsResponse {

    public String statusMessage;
    public boolean isError;
    public ArrayList<Comment> comments;

    public CommentsResponse() {
    }

}
