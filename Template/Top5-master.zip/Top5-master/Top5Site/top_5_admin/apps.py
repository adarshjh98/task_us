from django.apps import AppConfig


class Top5AdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'top_5_admin'
